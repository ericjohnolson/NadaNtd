﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQtoCSV
{
    public class DataRow : List<DataRowItem>, IDataRow
    {
    }
}
